﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace SyedS_PixelChessProgram
{
    class ClickManagement
    {
        public static int clickCount = 0;
        public static int movingPosition;

        public static Bitmap ClickInTake(PixelProgramForm form, int positionIndex, ref List<PositionTracker> list)
        {
            clickCount++;
            Bitmap returnBitmap = new Bitmap(100, 100);

            //if this is the first click in a two click move
            if (clickCount == 1)
            {
                //check if the click is on a square that is occupied
                //bool occupied = list[positionIndex].Occupied;
                if (!list[positionIndex].Occupied)//if it is not occupied then ignore this click, and reset the click count to 0, and return an empty bitmap to that spot;
                {
                    clickCount = 0;
                    return returnBitmap;
                }
                else//if the spot is not occupied then
                {
                    movingPosition = positionIndex;//remember the index of the click
                    returnBitmap = BitmapChooser(list[positionIndex].TypeOnSpot, list[positionIndex].TeamOnSpot);//return a matching image to not affect the image straight away
                    return returnBitmap;
                }
            }
            else if (clickCount == 2)//if this is the click in a two click move then 
            {
                //make old bitmap be the new bitmap for the position of the second click
                
                list[positionIndex].TypeOnSpot = list[movingPosition].TypeOnSpot;//change the position data
                list[positionIndex].TeamOnSpot = list[movingPosition].TeamOnSpot;//change the position data
                list[positionIndex].Occupied = true;
                EmptyPosition(movingPosition, ref list);//empty the old position
                returnBitmap = BitmapChooser(list[positionIndex].TypeOnSpot, list[positionIndex].TeamOnSpot);
                
                clickCount = 0;
                return returnBitmap;

            }
            else
            {
                //the third click will reset the count to 0
                clickCount = 0;
                //then continue the first click recursively
                return ClickInTake(form, positionIndex, ref list);
            }
        }

        private static Bitmap BitmapChooser(string type, string team)
        {
            Bitmap returnBitmap = new Bitmap(100, 100);

            switch (type)
            {
                case "pawn":
                    returnBitmap = BitmapFieldStorage.SetPawn(team);
                    break;
                case "rook":
                    returnBitmap = BitmapFieldStorage.SetRook(team);
                    break;
                case "knight":
                    returnBitmap = BitmapFieldStorage.SetKnight(team);
                    break;
                case "bishop":
                    returnBitmap = BitmapFieldStorage.SetBishop(team);
                    break;
                case "queen":
                    returnBitmap = BitmapFieldStorage.SetQueen(team);
                    break;
                case "king":
                    returnBitmap = BitmapFieldStorage.SetKing(team);
                    break;
            }

            return returnBitmap;
        }
        private static void EmptyPosition(int position, ref List<PositionTracker> list)
        {
            Bitmap emptySquareBmp = new Bitmap(100, 100);
            for (int y = 0; y < 100; y++)
            {
                for (int x = 0; x < 100; x++)
                {
                    emptySquareBmp.SetPixel(x, y, list[position].point.BackColor);
                }
            }
            list[position].point.Image = emptySquareBmp;

            list[position].TeamOnSpot = null;
            list[position].TypeOnSpot = null;
            list[position].Occupied = false;
        }
    }
}
