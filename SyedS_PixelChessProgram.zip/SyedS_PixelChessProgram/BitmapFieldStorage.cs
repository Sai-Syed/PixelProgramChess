﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;

namespace SyedS_PixelChessProgram
{
    class BitmapFieldStorage
    {
        /// <summary>
        /// A method so the program can understand string based color
        /// </summary>
        /// <param name="colorInput"></param>
        /// <returns></returns>
        public static Color ColorPicker(string colorInput)
        {
            if (colorInput == "white")
            {
                return Color.FromArgb(255, 255, 255, 255);
            }
            else
            {
                return Color.FromArgb(255, 0, 0, 0);
            }
        }
        /// <summary>
        /// A method to return a pawn shaped bitmap
        /// </summary>
        /// <param name="colorInput"></param>
        /// <returns></returns>
        public static Bitmap SetPawn(string colorInput)
        {
            Color colorOutput = ColorPicker(colorInput);

            Bitmap returnBitmap = new Bitmap(100, 100);

            for (int y = 70; y < 90; y++)
            {
                for (int x = 10; x < 90; x++)
                {
                    returnBitmap.SetPixel(x, y, colorOutput);
                }
            }
            for (int y = 30; y < 70; y++)
            {
                for (int x = 40; x < 60; x++)
                {
                    returnBitmap.SetPixel(x, y, colorOutput);
                }
            }

            return returnBitmap;
        }
        /// <summary>
        /// A method to return a rook shaped bitmap
        /// </summary>
        /// <param name="colorInput"></param>
        /// <returns></returns>
        public static Bitmap SetRook(string colorInput)
        {
            Color colorOutput = ColorPicker(colorInput);

            Bitmap returnBitmap = new Bitmap(100, 100);

            for (int y = 70; y < 90; y++)
            {
                for (int x = 10; x < 90; x++)
                {
                    returnBitmap.SetPixel(x, y, colorOutput);
                }
            }
            for (int y = 50; y < 70; y++)
            {
                for (int x = 40; x < 60; x++)
                {
                    returnBitmap.SetPixel(x, y, colorOutput);
                }
            }
            for (int y = 30; y < 50; y++)
            {
                for (int x = 20; x < 80; x++)
                {
                    returnBitmap.SetPixel(x, y, colorOutput);
                }
            }
            for (int y = 20; y < 30; y++)
            {
                for (int x = 20; x < 32; x++)
                {
                    returnBitmap.SetPixel(x, y, colorOutput);
                }
            }
            for (int y = 20; y < 30; y++)
            {
                for (int x = 44; x < 56; x++)
                {
                    returnBitmap.SetPixel(x, y, colorOutput);
                }
            }
            for (int y = 20; y < 30; y++)
            {
                for (int x = 68; x < 80; x++)
                {
                    returnBitmap.SetPixel(x, y, colorOutput);
                }
            }

            return returnBitmap;
        }
        /// <summary>
        /// A method to return a knight shaped bitmap
        /// </summary>
        /// <param name="colorInput"></param>
        /// <returns></returns>
        public static Bitmap SetKnight(string colorInput)
        {
            Color colorOutput = ColorPicker(colorInput);

            Bitmap returnBitmap = new Bitmap(100, 100);

            for (int y = 70; y < 90; y++)
            {
                for (int x = 10; x < 90; x++)
                {
                    returnBitmap.SetPixel(x, y, colorOutput);
                }
            }
            for (int y = 40; y < 70; y++)
            {
                for (int x = 40; x < 60; x++)
                {
                    returnBitmap.SetPixel(x, y, colorOutput);
                }
            }
            for (int y = 20; y < 50; y++)
            {
                for (int x = 30; x < 40; x++)
                {
                    returnBitmap.SetPixel(x, y, colorOutput);
                }
            }
            for (int y = 5; y < 20; y++)
            {
                for (int x = 30; x < 70; x++)
                {
                    returnBitmap.SetPixel(x, y, colorOutput);
                }
            }

            return returnBitmap;
        }
        /// <summary>
        /// A method to return a bishop shaped bitmap
        /// </summary>
        /// <param name="colorInput"></param>
        /// <returns></returns>
        public static Bitmap SetBishop(string colorInput)
        {
            Color colorOutput = ColorPicker(colorInput);

            Bitmap returnBitmap = new Bitmap(100, 100);

            for (int y = 70; y < 90; y++)
            {
                for (int x = 10; x < 90; x++)
                {
                    returnBitmap.SetPixel(x, y, colorOutput);
                }
            }
            for (int y = 50; y < 70; y++)
            {
                for (int x = 40; x < 60; x++)
                {
                    returnBitmap.SetPixel(x, y, colorOutput);
                }
            }
            for (int y = 40; y < 50; y++)
            {
                for (int x = 30; x < 70; x++)
                {
                    returnBitmap.SetPixel(x, y, colorOutput);
                }
            }
            for (int y = 25; y < 40; y++)
            {
                for (int x = 30; x < 40; x++)
                {
                    returnBitmap.SetPixel(x, y, colorOutput);
                }
            }
            for (int y = 25; y < 40; y++)
            {
                for (int x = 60; x < 70; x++)
                {
                    returnBitmap.SetPixel(x, y, colorOutput);
                }
            }
            for (int y = 20; y < 25; y++)
            {
                for (int x = 30; x < 70; x++)
                {
                    returnBitmap.SetPixel(x, y, colorOutput);
                }
            }
            for (int y = 10; y < 20; y++)
            {
                for (int x = 40; x < 60; x++)
                {
                    returnBitmap.SetPixel(x, y, colorOutput);
                }
            }

            return returnBitmap;
        }
        /// <summary>
        /// A method to return a queen shaped bitmap
        /// </summary>
        /// <param name="colorInput"></param>
        /// <returns></returns>
        public static Bitmap SetQueen(string colorInput)
        {
            Color colorOutput = ColorPicker(colorInput);

            Bitmap returnBitmap = new Bitmap(100, 100);

            for (int y = 70; y < 90; y++)
            {
                for (int x = 10; x < 90; x++)
                {
                    returnBitmap.SetPixel(x, y, colorOutput);
                }
            }
            for (int y = 10; y < 70; y++)
            {
                for (int x = 40; x < 60; x++)
                {
                    returnBitmap.SetPixel(x, y, colorOutput);
                }
            }
            for (int y = 10; y < 20; y++)
            {
                for (int x = 30; x < 70; x++)
                {
                    returnBitmap.SetPixel(x, y, colorOutput);
                }
            }
            for (int y = 30; y < 40; y++)
            {
                for (int x = 30; x < 70; x++)
                {
                    returnBitmap.SetPixel(x, y, colorOutput);
                }
            }
            for (int y = 50; y < 60; y++)
            {
                for (int x = 30; x < 70; x++)
                {
                    returnBitmap.SetPixel(x, y, colorOutput);
                }
            }
            for (int y = 10; y < 20; y++)
            {
                for (int x = 30; x < 70; x++)
                {
                    returnBitmap.SetPixel(x, y, colorOutput);
                }
            }

            return returnBitmap;
        }
        /// <summary>
        /// A method to return a king shaped bitmap
        /// </summary>
        /// <param name="colorInput"></param>
        /// <returns></returns>
        public static Bitmap SetKing(string colorInput)
        {
            Color colorOutput = ColorPicker(colorInput);

            Bitmap returnBitmap = new Bitmap(100, 100);

            for (int y = 70; y < 90; y++)
            {
                for (int x = 10; x < 90; x++)
                {
                    returnBitmap.SetPixel(x, y, colorOutput);
                }
            }
            for (int y = 30; y < 70; y++)
            {
                for (int x = 40; x < 60; x++)
                {
                    returnBitmap.SetPixel(x, y, colorOutput);
                }
            }
            for (int y = 10; y < 20; y++)
            {
                for (int x = 20; x < 80; x++)
                {
                    returnBitmap.SetPixel(x, y, colorOutput);
                }
            }
            for (int y = 10; y < 50; y++)
            {
                for (int x = 20; x < 30; x++)
                {
                    returnBitmap.SetPixel(x, y, colorOutput);
                }
            }
            for (int y = 50; y < 60; y++)
            {
                for (int x = 20; x < 80; x++)
                {
                    returnBitmap.SetPixel(x, y, colorOutput);
                }
            }
            for (int y = 10; y < 50; y++)
            {
                for (int x = 70; x < 80; x++)
                {
                    returnBitmap.SetPixel(x, y, colorOutput);
                }
            }

            return returnBitmap;
        }

    }
}
