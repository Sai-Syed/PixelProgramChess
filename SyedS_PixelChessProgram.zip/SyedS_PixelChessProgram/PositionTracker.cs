﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SyedS_PixelChessProgram
{
    class PositionTracker
    {
        public string Name;
        public bool Occupied;
        public string TeamOnSpot;
        public string TypeOnSpot;
        public int positionIndex;
        public PictureBox point;
        private static int positionIndexCounter = 0;
        public PositionTracker(string name, bool occupied, string teamOnSpot, string typeOnSpot, PictureBox position)
        {
            this.Name = name;
            this.Occupied = occupied;
            this.TeamOnSpot = teamOnSpot;
            this.TypeOnSpot = typeOnSpot;
            this.point = position;
            positionIndex = positionIndexCounter;
            positionIndexCounter++;
        }
        public PositionTracker(string name, bool occupied, string teamOnSpot, string typeOnSpot)
        {
            this.Name = name;
            this.Occupied = occupied;
            this.TeamOnSpot = teamOnSpot;
            this.TypeOnSpot = typeOnSpot;
            positionIndex = positionIndexCounter;
            positionIndexCounter++;
        }
        public PositionTracker(string name, bool occupied, PictureBox position)
        {
            this.Name = name;
            this.Occupied = occupied;
            this.point = position;
            positionIndex = positionIndexCounter;
            positionIndexCounter++;
        }

    }
}
