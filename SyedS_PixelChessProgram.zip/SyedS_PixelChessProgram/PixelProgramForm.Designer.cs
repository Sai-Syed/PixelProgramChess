﻿namespace SyedS_PixelChessProgram
{
    partial class PixelProgramForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BoardBack = new System.Windows.Forms.PictureBox();
            this.H1 = new System.Windows.Forms.PictureBox();
            this.G1 = new System.Windows.Forms.PictureBox();
            this.F1 = new System.Windows.Forms.PictureBox();
            this.H2 = new System.Windows.Forms.PictureBox();
            this.G2 = new System.Windows.Forms.PictureBox();
            this.G3 = new System.Windows.Forms.PictureBox();
            this.H3 = new System.Windows.Forms.PictureBox();
            this.F3 = new System.Windows.Forms.PictureBox();
            this.H4 = new System.Windows.Forms.PictureBox();
            this.F2 = new System.Windows.Forms.PictureBox();
            this.F7 = new System.Windows.Forms.PictureBox();
            this.G4 = new System.Windows.Forms.PictureBox();
            this.A1 = new System.Windows.Forms.PictureBox();
            this.H8 = new System.Windows.Forms.PictureBox();
            this.H7 = new System.Windows.Forms.PictureBox();
            this.H6 = new System.Windows.Forms.PictureBox();
            this.G5 = new System.Windows.Forms.PictureBox();
            this.G6 = new System.Windows.Forms.PictureBox();
            this.G7 = new System.Windows.Forms.PictureBox();
            this.G8 = new System.Windows.Forms.PictureBox();
            this.F5 = new System.Windows.Forms.PictureBox();
            this.D7 = new System.Windows.Forms.PictureBox();
            this.C1 = new System.Windows.Forms.PictureBox();
            this.F8 = new System.Windows.Forms.PictureBox();
            this.D1 = new System.Windows.Forms.PictureBox();
            this.H5 = new System.Windows.Forms.PictureBox();
            this.F4 = new System.Windows.Forms.PictureBox();
            this.F6 = new System.Windows.Forms.PictureBox();
            this.A2 = new System.Windows.Forms.PictureBox();
            this.E6 = new System.Windows.Forms.PictureBox();
            this.E5 = new System.Windows.Forms.PictureBox();
            this.D5 = new System.Windows.Forms.PictureBox();
            this.E8 = new System.Windows.Forms.PictureBox();
            this.E7 = new System.Windows.Forms.PictureBox();
            this.D4 = new System.Windows.Forms.PictureBox();
            this.E4 = new System.Windows.Forms.PictureBox();
            this.D2 = new System.Windows.Forms.PictureBox();
            this.D6 = new System.Windows.Forms.PictureBox();
            this.D3 = new System.Windows.Forms.PictureBox();
            this.C6 = new System.Windows.Forms.PictureBox();
            this.C4 = new System.Windows.Forms.PictureBox();
            this.E2 = new System.Windows.Forms.PictureBox();
            this.D8 = new System.Windows.Forms.PictureBox();
            this.C5 = new System.Windows.Forms.PictureBox();
            this.B2 = new System.Windows.Forms.PictureBox();
            this.B1 = new System.Windows.Forms.PictureBox();
            this.C2 = new System.Windows.Forms.PictureBox();
            this.A3 = new System.Windows.Forms.PictureBox();
            this.B3 = new System.Windows.Forms.PictureBox();
            this.E1 = new System.Windows.Forms.PictureBox();
            this.E3 = new System.Windows.Forms.PictureBox();
            this.C3 = new System.Windows.Forms.PictureBox();
            this.B4 = new System.Windows.Forms.PictureBox();
            this.A4 = new System.Windows.Forms.PictureBox();
            this.A5 = new System.Windows.Forms.PictureBox();
            this.B5 = new System.Windows.Forms.PictureBox();
            this.B6 = new System.Windows.Forms.PictureBox();
            this.A6 = new System.Windows.Forms.PictureBox();
            this.A7 = new System.Windows.Forms.PictureBox();
            this.B7 = new System.Windows.Forms.PictureBox();
            this.B8 = new System.Windows.Forms.PictureBox();
            this.A8 = new System.Windows.Forms.PictureBox();
            this.C7 = new System.Windows.Forms.PictureBox();
            this.C8 = new System.Windows.Forms.PictureBox();
            this.txtA = new System.Windows.Forms.TextBox();
            this.txtB = new System.Windows.Forms.TextBox();
            this.txtC = new System.Windows.Forms.TextBox();
            this.txtD = new System.Windows.Forms.TextBox();
            this.txtH = new System.Windows.Forms.TextBox();
            this.txtG = new System.Windows.Forms.TextBox();
            this.txtF = new System.Windows.Forms.TextBox();
            this.txtE = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.BoardBack)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.H1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.G1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.F1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.H2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.G2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.G3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.H3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.F3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.H4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.F2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.F7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.G4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.A1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.H8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.H7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.H6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.G5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.G6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.G7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.G8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.F5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.D7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.F8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.D1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.H5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.F4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.F6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.A2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.E6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.E5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.D5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.E8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.E7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.D4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.E4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.D2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.D6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.D3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.E2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.D8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.B2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.B1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.A3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.B3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.E1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.E3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.B4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.A4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.A5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.B5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.B6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.A6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.A7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.B7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.B8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.A8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C8)).BeginInit();
            this.SuspendLayout();
            // 
            // BoardBack
            // 
            this.BoardBack.BackColor = System.Drawing.Color.Maroon;
            this.BoardBack.Location = new System.Drawing.Point(100, 100);
            this.BoardBack.Name = "BoardBack";
            this.BoardBack.Size = new System.Drawing.Size(820, 820);
            this.BoardBack.TabIndex = 0;
            this.BoardBack.TabStop = false;
            // 
            // H1
            // 
            this.H1.BackColor = System.Drawing.Color.Moccasin;
            this.H1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.H1.Location = new System.Drawing.Point(110, 110);
            this.H1.Name = "H1";
            this.H1.Size = new System.Drawing.Size(100, 100);
            this.H1.TabIndex = 2;
            this.H1.TabStop = false;
            this.H1.Click += new System.EventHandler(this.H1_Click);
            // 
            // G1
            // 
            this.G1.BackColor = System.Drawing.Color.Sienna;
            this.G1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.G1.Location = new System.Drawing.Point(110, 210);
            this.G1.Name = "G1";
            this.G1.Size = new System.Drawing.Size(100, 100);
            this.G1.TabIndex = 2;
            this.G1.TabStop = false;
            this.G1.Click += new System.EventHandler(this.G1_Click);
            // 
            // F1
            // 
            this.F1.BackColor = System.Drawing.Color.Moccasin;
            this.F1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.F1.Location = new System.Drawing.Point(110, 310);
            this.F1.Name = "F1";
            this.F1.Size = new System.Drawing.Size(100, 100);
            this.F1.TabIndex = 2;
            this.F1.TabStop = false;
            this.F1.Click += new System.EventHandler(this.F1_Click);
            // 
            // H2
            // 
            this.H2.BackColor = System.Drawing.Color.Sienna;
            this.H2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.H2.Location = new System.Drawing.Point(210, 110);
            this.H2.Name = "H2";
            this.H2.Size = new System.Drawing.Size(100, 100);
            this.H2.TabIndex = 2;
            this.H2.TabStop = false;
            this.H2.Click += new System.EventHandler(this.H2_Click);
            // 
            // G2
            // 
            this.G2.BackColor = System.Drawing.Color.Moccasin;
            this.G2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.G2.Location = new System.Drawing.Point(210, 210);
            this.G2.Name = "G2";
            this.G2.Size = new System.Drawing.Size(100, 100);
            this.G2.TabIndex = 2;
            this.G2.TabStop = false;
            this.G2.Click += new System.EventHandler(this.G2_Click);
            // 
            // G3
            // 
            this.G3.BackColor = System.Drawing.Color.Sienna;
            this.G3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.G3.Location = new System.Drawing.Point(310, 210);
            this.G3.Name = "G3";
            this.G3.Size = new System.Drawing.Size(100, 100);
            this.G3.TabIndex = 2;
            this.G3.TabStop = false;
            this.G3.Click += new System.EventHandler(this.G3_Click);
            // 
            // H3
            // 
            this.H3.BackColor = System.Drawing.Color.Moccasin;
            this.H3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.H3.Location = new System.Drawing.Point(310, 110);
            this.H3.Name = "H3";
            this.H3.Size = new System.Drawing.Size(100, 100);
            this.H3.TabIndex = 2;
            this.H3.TabStop = false;
            this.H3.Click += new System.EventHandler(this.H3_Click);
            // 
            // F3
            // 
            this.F3.BackColor = System.Drawing.Color.Moccasin;
            this.F3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.F3.Location = new System.Drawing.Point(310, 310);
            this.F3.Name = "F3";
            this.F3.Size = new System.Drawing.Size(100, 100);
            this.F3.TabIndex = 2;
            this.F3.TabStop = false;
            this.F3.Click += new System.EventHandler(this.F3_Click);
            // 
            // H4
            // 
            this.H4.BackColor = System.Drawing.Color.Sienna;
            this.H4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.H4.Location = new System.Drawing.Point(410, 110);
            this.H4.Name = "H4";
            this.H4.Size = new System.Drawing.Size(100, 100);
            this.H4.TabIndex = 2;
            this.H4.TabStop = false;
            this.H4.Click += new System.EventHandler(this.H4_Click);
            // 
            // F2
            // 
            this.F2.BackColor = System.Drawing.Color.Sienna;
            this.F2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.F2.Location = new System.Drawing.Point(210, 310);
            this.F2.Name = "F2";
            this.F2.Size = new System.Drawing.Size(100, 100);
            this.F2.TabIndex = 2;
            this.F2.TabStop = false;
            this.F2.Click += new System.EventHandler(this.F2_Click);
            // 
            // F7
            // 
            this.F7.BackColor = System.Drawing.Color.Moccasin;
            this.F7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.F7.Location = new System.Drawing.Point(710, 310);
            this.F7.Name = "F7";
            this.F7.Size = new System.Drawing.Size(100, 100);
            this.F7.TabIndex = 2;
            this.F7.TabStop = false;
            this.F7.Click += new System.EventHandler(this.F7_Click);
            // 
            // G4
            // 
            this.G4.BackColor = System.Drawing.Color.Moccasin;
            this.G4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.G4.Location = new System.Drawing.Point(410, 210);
            this.G4.Name = "G4";
            this.G4.Size = new System.Drawing.Size(100, 100);
            this.G4.TabIndex = 2;
            this.G4.TabStop = false;
            this.G4.Click += new System.EventHandler(this.G4_Click);
            // 
            // A1
            // 
            this.A1.BackColor = System.Drawing.Color.Sienna;
            this.A1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.A1.Location = new System.Drawing.Point(110, 810);
            this.A1.Name = "A1";
            this.A1.Size = new System.Drawing.Size(100, 100);
            this.A1.TabIndex = 2;
            this.A1.TabStop = false;
            this.A1.Click += new System.EventHandler(this.A1_Click);
            // 
            // H8
            // 
            this.H8.BackColor = System.Drawing.Color.Sienna;
            this.H8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.H8.Location = new System.Drawing.Point(810, 110);
            this.H8.Name = "H8";
            this.H8.Size = new System.Drawing.Size(100, 100);
            this.H8.TabIndex = 2;
            this.H8.TabStop = false;
            this.H8.Click += new System.EventHandler(this.H8_Click);
            // 
            // H7
            // 
            this.H7.BackColor = System.Drawing.Color.Moccasin;
            this.H7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.H7.Location = new System.Drawing.Point(710, 110);
            this.H7.Name = "H7";
            this.H7.Size = new System.Drawing.Size(100, 100);
            this.H7.TabIndex = 2;
            this.H7.TabStop = false;
            this.H7.Click += new System.EventHandler(this.H7_Click);
            // 
            // H6
            // 
            this.H6.BackColor = System.Drawing.Color.Sienna;
            this.H6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.H6.Location = new System.Drawing.Point(610, 110);
            this.H6.Name = "H6";
            this.H6.Size = new System.Drawing.Size(100, 100);
            this.H6.TabIndex = 2;
            this.H6.TabStop = false;
            this.H6.Click += new System.EventHandler(this.H6_Click);
            // 
            // G5
            // 
            this.G5.BackColor = System.Drawing.Color.Sienna;
            this.G5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.G5.Location = new System.Drawing.Point(510, 210);
            this.G5.Name = "G5";
            this.G5.Size = new System.Drawing.Size(100, 100);
            this.G5.TabIndex = 2;
            this.G5.TabStop = false;
            this.G5.Click += new System.EventHandler(this.G5_Click);
            // 
            // G6
            // 
            this.G6.BackColor = System.Drawing.Color.Moccasin;
            this.G6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.G6.Location = new System.Drawing.Point(610, 210);
            this.G6.Name = "G6";
            this.G6.Size = new System.Drawing.Size(100, 100);
            this.G6.TabIndex = 2;
            this.G6.TabStop = false;
            this.G6.Click += new System.EventHandler(this.G6_Click);
            // 
            // G7
            // 
            this.G7.BackColor = System.Drawing.Color.Sienna;
            this.G7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.G7.Location = new System.Drawing.Point(710, 210);
            this.G7.Name = "G7";
            this.G7.Size = new System.Drawing.Size(100, 100);
            this.G7.TabIndex = 2;
            this.G7.TabStop = false;
            this.G7.Click += new System.EventHandler(this.G7_Click);
            // 
            // G8
            // 
            this.G8.BackColor = System.Drawing.Color.Moccasin;
            this.G8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.G8.Location = new System.Drawing.Point(810, 210);
            this.G8.Name = "G8";
            this.G8.Size = new System.Drawing.Size(100, 100);
            this.G8.TabIndex = 2;
            this.G8.TabStop = false;
            this.G8.Click += new System.EventHandler(this.G8_Click);
            // 
            // F5
            // 
            this.F5.BackColor = System.Drawing.Color.Moccasin;
            this.F5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.F5.Location = new System.Drawing.Point(510, 310);
            this.F5.Name = "F5";
            this.F5.Size = new System.Drawing.Size(100, 100);
            this.F5.TabIndex = 2;
            this.F5.TabStop = false;
            this.F5.Click += new System.EventHandler(this.F5_Click);
            // 
            // D7
            // 
            this.D7.BackColor = System.Drawing.Color.Moccasin;
            this.D7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.D7.Location = new System.Drawing.Point(710, 510);
            this.D7.Name = "D7";
            this.D7.Size = new System.Drawing.Size(100, 100);
            this.D7.TabIndex = 2;
            this.D7.TabStop = false;
            this.D7.Click += new System.EventHandler(this.D7_Click);
            // 
            // C1
            // 
            this.C1.BackColor = System.Drawing.Color.Sienna;
            this.C1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.C1.Location = new System.Drawing.Point(110, 610);
            this.C1.Name = "C1";
            this.C1.Size = new System.Drawing.Size(100, 100);
            this.C1.TabIndex = 2;
            this.C1.TabStop = false;
            this.C1.Click += new System.EventHandler(this.C1_Click);
            // 
            // F8
            // 
            this.F8.BackColor = System.Drawing.Color.Sienna;
            this.F8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.F8.Location = new System.Drawing.Point(810, 310);
            this.F8.Name = "F8";
            this.F8.Size = new System.Drawing.Size(100, 100);
            this.F8.TabIndex = 2;
            this.F8.TabStop = false;
            this.F8.Click += new System.EventHandler(this.F8_Click);
            // 
            // D1
            // 
            this.D1.BackColor = System.Drawing.Color.Moccasin;
            this.D1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.D1.Location = new System.Drawing.Point(110, 510);
            this.D1.Name = "D1";
            this.D1.Size = new System.Drawing.Size(100, 100);
            this.D1.TabIndex = 2;
            this.D1.TabStop = false;
            this.D1.Click += new System.EventHandler(this.D1_Click);
            // 
            // H5
            // 
            this.H5.BackColor = System.Drawing.Color.Moccasin;
            this.H5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.H5.Location = new System.Drawing.Point(510, 110);
            this.H5.Name = "H5";
            this.H5.Size = new System.Drawing.Size(100, 100);
            this.H5.TabIndex = 2;
            this.H5.TabStop = false;
            this.H5.Click += new System.EventHandler(this.H5_Click);
            // 
            // F4
            // 
            this.F4.BackColor = System.Drawing.Color.Sienna;
            this.F4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.F4.Location = new System.Drawing.Point(410, 310);
            this.F4.Name = "F4";
            this.F4.Size = new System.Drawing.Size(100, 100);
            this.F4.TabIndex = 2;
            this.F4.TabStop = false;
            this.F4.Click += new System.EventHandler(this.F4_Click);
            // 
            // F6
            // 
            this.F6.BackColor = System.Drawing.Color.Sienna;
            this.F6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.F6.Location = new System.Drawing.Point(610, 310);
            this.F6.Name = "F6";
            this.F6.Size = new System.Drawing.Size(100, 100);
            this.F6.TabIndex = 2;
            this.F6.TabStop = false;
            this.F6.Click += new System.EventHandler(this.F6_Click);
            // 
            // A2
            // 
            this.A2.BackColor = System.Drawing.Color.Moccasin;
            this.A2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.A2.Location = new System.Drawing.Point(210, 810);
            this.A2.Name = "A2";
            this.A2.Size = new System.Drawing.Size(100, 100);
            this.A2.TabIndex = 2;
            this.A2.TabStop = false;
            this.A2.Click += new System.EventHandler(this.A2_Click);
            // 
            // E6
            // 
            this.E6.BackColor = System.Drawing.Color.Moccasin;
            this.E6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.E6.Location = new System.Drawing.Point(610, 410);
            this.E6.Name = "E6";
            this.E6.Size = new System.Drawing.Size(100, 100);
            this.E6.TabIndex = 2;
            this.E6.TabStop = false;
            this.E6.Click += new System.EventHandler(this.E6_Click);
            // 
            // E5
            // 
            this.E5.BackColor = System.Drawing.Color.Sienna;
            this.E5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.E5.Location = new System.Drawing.Point(510, 410);
            this.E5.Name = "E5";
            this.E5.Size = new System.Drawing.Size(100, 100);
            this.E5.TabIndex = 2;
            this.E5.TabStop = false;
            this.E5.Click += new System.EventHandler(this.E5_Click);
            // 
            // D5
            // 
            this.D5.BackColor = System.Drawing.Color.Moccasin;
            this.D5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.D5.Location = new System.Drawing.Point(510, 510);
            this.D5.Name = "D5";
            this.D5.Size = new System.Drawing.Size(100, 100);
            this.D5.TabIndex = 2;
            this.D5.TabStop = false;
            this.D5.Click += new System.EventHandler(this.D5_Click);
            // 
            // E8
            // 
            this.E8.BackColor = System.Drawing.Color.Moccasin;
            this.E8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.E8.Location = new System.Drawing.Point(810, 410);
            this.E8.Name = "E8";
            this.E8.Size = new System.Drawing.Size(100, 100);
            this.E8.TabIndex = 2;
            this.E8.TabStop = false;
            this.E8.Click += new System.EventHandler(this.E8_Click);
            // 
            // E7
            // 
            this.E7.BackColor = System.Drawing.Color.Sienna;
            this.E7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.E7.Location = new System.Drawing.Point(710, 410);
            this.E7.Name = "E7";
            this.E7.Size = new System.Drawing.Size(100, 100);
            this.E7.TabIndex = 2;
            this.E7.TabStop = false;
            this.E7.Click += new System.EventHandler(this.E7_Click);
            // 
            // D4
            // 
            this.D4.BackColor = System.Drawing.Color.Sienna;
            this.D4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.D4.Location = new System.Drawing.Point(410, 510);
            this.D4.Name = "D4";
            this.D4.Size = new System.Drawing.Size(100, 100);
            this.D4.TabIndex = 2;
            this.D4.TabStop = false;
            this.D4.Click += new System.EventHandler(this.D4_Click);
            // 
            // E4
            // 
            this.E4.BackColor = System.Drawing.Color.Moccasin;
            this.E4.Location = new System.Drawing.Point(410, 410);
            this.E4.Name = "E4";
            this.E4.Size = new System.Drawing.Size(100, 100);
            this.E4.TabIndex = 2;
            this.E4.TabStop = false;
            this.E4.Click += new System.EventHandler(this.E4_Click);
            // 
            // D2
            // 
            this.D2.BackColor = System.Drawing.Color.Sienna;
            this.D2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.D2.Location = new System.Drawing.Point(210, 510);
            this.D2.Name = "D2";
            this.D2.Size = new System.Drawing.Size(100, 100);
            this.D2.TabIndex = 2;
            this.D2.TabStop = false;
            this.D2.Click += new System.EventHandler(this.D2_Click);
            // 
            // D6
            // 
            this.D6.BackColor = System.Drawing.Color.Sienna;
            this.D6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.D6.Location = new System.Drawing.Point(610, 510);
            this.D6.Name = "D6";
            this.D6.Size = new System.Drawing.Size(100, 100);
            this.D6.TabIndex = 2;
            this.D6.TabStop = false;
            this.D6.Click += new System.EventHandler(this.D6_Click);
            // 
            // D3
            // 
            this.D3.BackColor = System.Drawing.Color.Moccasin;
            this.D3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.D3.Location = new System.Drawing.Point(310, 510);
            this.D3.Name = "D3";
            this.D3.Size = new System.Drawing.Size(100, 100);
            this.D3.TabIndex = 2;
            this.D3.TabStop = false;
            this.D3.Click += new System.EventHandler(this.D3_Click);
            // 
            // C6
            // 
            this.C6.BackColor = System.Drawing.Color.Moccasin;
            this.C6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.C6.Location = new System.Drawing.Point(610, 610);
            this.C6.Name = "C6";
            this.C6.Size = new System.Drawing.Size(100, 100);
            this.C6.TabIndex = 2;
            this.C6.TabStop = false;
            this.C6.Click += new System.EventHandler(this.C6_Click);
            // 
            // C4
            // 
            this.C4.BackColor = System.Drawing.Color.Moccasin;
            this.C4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.C4.Location = new System.Drawing.Point(410, 610);
            this.C4.Name = "C4";
            this.C4.Size = new System.Drawing.Size(100, 100);
            this.C4.TabIndex = 2;
            this.C4.TabStop = false;
            this.C4.Click += new System.EventHandler(this.C4_Click);
            // 
            // E2
            // 
            this.E2.BackColor = System.Drawing.Color.Moccasin;
            this.E2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.E2.Location = new System.Drawing.Point(210, 410);
            this.E2.Name = "E2";
            this.E2.Size = new System.Drawing.Size(100, 100);
            this.E2.TabIndex = 2;
            this.E2.TabStop = false;
            this.E2.Click += new System.EventHandler(this.E2_Click);
            // 
            // D8
            // 
            this.D8.BackColor = System.Drawing.Color.Sienna;
            this.D8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.D8.Location = new System.Drawing.Point(810, 510);
            this.D8.Name = "D8";
            this.D8.Size = new System.Drawing.Size(100, 100);
            this.D8.TabIndex = 2;
            this.D8.TabStop = false;
            this.D8.Click += new System.EventHandler(this.D8_Click);
            // 
            // C5
            // 
            this.C5.BackColor = System.Drawing.Color.Sienna;
            this.C5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.C5.Location = new System.Drawing.Point(510, 610);
            this.C5.Name = "C5";
            this.C5.Size = new System.Drawing.Size(100, 100);
            this.C5.TabIndex = 2;
            this.C5.TabStop = false;
            this.C5.Click += new System.EventHandler(this.C5_Click);
            // 
            // B2
            // 
            this.B2.BackColor = System.Drawing.Color.Sienna;
            this.B2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.B2.Location = new System.Drawing.Point(210, 710);
            this.B2.Name = "B2";
            this.B2.Size = new System.Drawing.Size(100, 100);
            this.B2.TabIndex = 2;
            this.B2.TabStop = false;
            this.B2.Click += new System.EventHandler(this.B2_Click);
            // 
            // B1
            // 
            this.B1.BackColor = System.Drawing.Color.Moccasin;
            this.B1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.B1.Location = new System.Drawing.Point(110, 710);
            this.B1.Name = "B1";
            this.B1.Size = new System.Drawing.Size(100, 100);
            this.B1.TabIndex = 2;
            this.B1.TabStop = false;
            this.B1.Click += new System.EventHandler(this.B1_Click);
            // 
            // C2
            // 
            this.C2.BackColor = System.Drawing.Color.Moccasin;
            this.C2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.C2.Location = new System.Drawing.Point(210, 610);
            this.C2.Name = "C2";
            this.C2.Size = new System.Drawing.Size(100, 100);
            this.C2.TabIndex = 2;
            this.C2.TabStop = false;
            this.C2.Click += new System.EventHandler(this.C2_Click);
            // 
            // A3
            // 
            this.A3.BackColor = System.Drawing.Color.Sienna;
            this.A3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.A3.Location = new System.Drawing.Point(310, 810);
            this.A3.Name = "A3";
            this.A3.Size = new System.Drawing.Size(100, 100);
            this.A3.TabIndex = 2;
            this.A3.TabStop = false;
            this.A3.Click += new System.EventHandler(this.A3_Click);
            // 
            // B3
            // 
            this.B3.BackColor = System.Drawing.Color.Moccasin;
            this.B3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.B3.Location = new System.Drawing.Point(310, 710);
            this.B3.Name = "B3";
            this.B3.Size = new System.Drawing.Size(100, 100);
            this.B3.TabIndex = 2;
            this.B3.TabStop = false;
            this.B3.Click += new System.EventHandler(this.B3_Click);
            // 
            // E1
            // 
            this.E1.BackColor = System.Drawing.Color.Sienna;
            this.E1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.E1.Location = new System.Drawing.Point(110, 410);
            this.E1.Name = "E1";
            this.E1.Size = new System.Drawing.Size(100, 100);
            this.E1.TabIndex = 2;
            this.E1.TabStop = false;
            this.E1.Click += new System.EventHandler(this.E1_Click);
            // 
            // E3
            // 
            this.E3.BackColor = System.Drawing.Color.Sienna;
            this.E3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.E3.Location = new System.Drawing.Point(310, 410);
            this.E3.Name = "E3";
            this.E3.Size = new System.Drawing.Size(100, 100);
            this.E3.TabIndex = 2;
            this.E3.TabStop = false;
            this.E3.Click += new System.EventHandler(this.E3_Click);
            // 
            // C3
            // 
            this.C3.BackColor = System.Drawing.Color.Sienna;
            this.C3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.C3.Location = new System.Drawing.Point(310, 610);
            this.C3.Name = "C3";
            this.C3.Size = new System.Drawing.Size(100, 100);
            this.C3.TabIndex = 2;
            this.C3.TabStop = false;
            this.C3.Click += new System.EventHandler(this.C3_Click);
            // 
            // B4
            // 
            this.B4.BackColor = System.Drawing.Color.Sienna;
            this.B4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.B4.Location = new System.Drawing.Point(410, 710);
            this.B4.Name = "B4";
            this.B4.Size = new System.Drawing.Size(100, 100);
            this.B4.TabIndex = 2;
            this.B4.TabStop = false;
            this.B4.Click += new System.EventHandler(this.B4_Click);
            // 
            // A4
            // 
            this.A4.BackColor = System.Drawing.Color.Moccasin;
            this.A4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.A4.Location = new System.Drawing.Point(410, 810);
            this.A4.Name = "A4";
            this.A4.Size = new System.Drawing.Size(100, 100);
            this.A4.TabIndex = 2;
            this.A4.TabStop = false;
            this.A4.Click += new System.EventHandler(this.A4_Click);
            // 
            // A5
            // 
            this.A5.BackColor = System.Drawing.Color.Sienna;
            this.A5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.A5.Location = new System.Drawing.Point(510, 810);
            this.A5.Name = "A5";
            this.A5.Size = new System.Drawing.Size(100, 100);
            this.A5.TabIndex = 2;
            this.A5.TabStop = false;
            this.A5.Click += new System.EventHandler(this.A5_Click);
            // 
            // B5
            // 
            this.B5.BackColor = System.Drawing.Color.Moccasin;
            this.B5.Location = new System.Drawing.Point(510, 710);
            this.B5.Name = "B5";
            this.B5.Size = new System.Drawing.Size(100, 100);
            this.B5.TabIndex = 2;
            this.B5.TabStop = false;
            this.B5.Click += new System.EventHandler(this.B5_Click);
            // 
            // B6
            // 
            this.B6.BackColor = System.Drawing.Color.Sienna;
            this.B6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.B6.Location = new System.Drawing.Point(610, 710);
            this.B6.Name = "B6";
            this.B6.Size = new System.Drawing.Size(100, 100);
            this.B6.TabIndex = 2;
            this.B6.TabStop = false;
            this.B6.Click += new System.EventHandler(this.B6_Click);
            // 
            // A6
            // 
            this.A6.BackColor = System.Drawing.Color.Moccasin;
            this.A6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.A6.Location = new System.Drawing.Point(610, 810);
            this.A6.Name = "A6";
            this.A6.Size = new System.Drawing.Size(100, 100);
            this.A6.TabIndex = 2;
            this.A6.TabStop = false;
            this.A6.Click += new System.EventHandler(this.A6_Click);
            // 
            // A7
            // 
            this.A7.BackColor = System.Drawing.Color.Sienna;
            this.A7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.A7.Location = new System.Drawing.Point(710, 810);
            this.A7.Name = "A7";
            this.A7.Size = new System.Drawing.Size(100, 100);
            this.A7.TabIndex = 2;
            this.A7.TabStop = false;
            this.A7.Click += new System.EventHandler(this.A7_Click);
            // 
            // B7
            // 
            this.B7.BackColor = System.Drawing.Color.Moccasin;
            this.B7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.B7.Location = new System.Drawing.Point(710, 710);
            this.B7.Name = "B7";
            this.B7.Size = new System.Drawing.Size(100, 100);
            this.B7.TabIndex = 2;
            this.B7.TabStop = false;
            this.B7.Click += new System.EventHandler(this.B7_Click);
            // 
            // B8
            // 
            this.B8.BackColor = System.Drawing.Color.Sienna;
            this.B8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.B8.Location = new System.Drawing.Point(810, 710);
            this.B8.Name = "B8";
            this.B8.Size = new System.Drawing.Size(100, 100);
            this.B8.TabIndex = 2;
            this.B8.TabStop = false;
            this.B8.Click += new System.EventHandler(this.B8_Click);
            // 
            // A8
            // 
            this.A8.BackColor = System.Drawing.Color.Moccasin;
            this.A8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.A8.Location = new System.Drawing.Point(810, 810);
            this.A8.Name = "A8";
            this.A8.Size = new System.Drawing.Size(100, 100);
            this.A8.TabIndex = 2;
            this.A8.TabStop = false;
            this.A8.Click += new System.EventHandler(this.A8_Click);
            // 
            // C7
            // 
            this.C7.BackColor = System.Drawing.Color.Sienna;
            this.C7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.C7.Location = new System.Drawing.Point(710, 610);
            this.C7.Name = "C7";
            this.C7.Size = new System.Drawing.Size(100, 100);
            this.C7.TabIndex = 2;
            this.C7.TabStop = false;
            this.C7.Click += new System.EventHandler(this.C7_Click);
            // 
            // C8
            // 
            this.C8.BackColor = System.Drawing.Color.Moccasin;
            this.C8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.C8.Location = new System.Drawing.Point(810, 610);
            this.C8.Name = "C8";
            this.C8.Size = new System.Drawing.Size(100, 100);
            this.C8.TabIndex = 2;
            this.C8.TabStop = false;
            this.C8.Click += new System.EventHandler(this.C8_Click);
            // 
            // txtA
            // 
            this.txtA.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtA.Location = new System.Drawing.Point(44, 843);
            this.txtA.Name = "txtA";
            this.txtA.ReadOnly = true;
            this.txtA.Size = new System.Drawing.Size(50, 43);
            this.txtA.TabIndex = 3;
            this.txtA.Text = "A";
            this.txtA.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtB
            // 
            this.txtB.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtB.Location = new System.Drawing.Point(44, 740);
            this.txtB.Name = "txtB";
            this.txtB.ReadOnly = true;
            this.txtB.Size = new System.Drawing.Size(50, 43);
            this.txtB.TabIndex = 3;
            this.txtB.Text = "B";
            this.txtB.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtC
            // 
            this.txtC.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtC.Location = new System.Drawing.Point(44, 638);
            this.txtC.Name = "txtC";
            this.txtC.ReadOnly = true;
            this.txtC.Size = new System.Drawing.Size(50, 43);
            this.txtC.TabIndex = 3;
            this.txtC.Text = "C";
            this.txtC.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtD
            // 
            this.txtD.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtD.Location = new System.Drawing.Point(44, 538);
            this.txtD.Name = "txtD";
            this.txtD.ReadOnly = true;
            this.txtD.Size = new System.Drawing.Size(50, 43);
            this.txtD.TabIndex = 3;
            this.txtD.Text = "D";
            this.txtD.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtH
            // 
            this.txtH.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtH.Location = new System.Drawing.Point(44, 132);
            this.txtH.Name = "txtH";
            this.txtH.ReadOnly = true;
            this.txtH.Size = new System.Drawing.Size(50, 43);
            this.txtH.TabIndex = 3;
            this.txtH.Text = "H";
            this.txtH.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtG
            // 
            this.txtG.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtG.Location = new System.Drawing.Point(44, 232);
            this.txtG.Name = "txtG";
            this.txtG.ReadOnly = true;
            this.txtG.Size = new System.Drawing.Size(50, 43);
            this.txtG.TabIndex = 3;
            this.txtG.Text = "G";
            this.txtG.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtF
            // 
            this.txtF.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtF.ForeColor = System.Drawing.Color.Black;
            this.txtF.Location = new System.Drawing.Point(44, 334);
            this.txtF.Name = "txtF";
            this.txtF.ReadOnly = true;
            this.txtF.Size = new System.Drawing.Size(50, 43);
            this.txtF.TabIndex = 3;
            this.txtF.Text = "F";
            this.txtF.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtE
            // 
            this.txtE.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtE.Location = new System.Drawing.Point(44, 437);
            this.txtE.Name = "txtE";
            this.txtE.ReadOnly = true;
            this.txtE.Size = new System.Drawing.Size(50, 43);
            this.txtE.TabIndex = 3;
            this.txtE.Text = "E";
            this.txtE.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.textBox1.Location = new System.Drawing.Point(133, 51);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(50, 43);
            this.textBox1.TabIndex = 3;
            this.textBox1.Text = "1";
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.textBox2.Location = new System.Drawing.Point(236, 51);
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(50, 43);
            this.textBox2.TabIndex = 3;
            this.textBox2.Text = "2";
            this.textBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox3
            // 
            this.textBox3.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.textBox3.Location = new System.Drawing.Point(338, 51);
            this.textBox3.Name = "textBox3";
            this.textBox3.ReadOnly = true;
            this.textBox3.Size = new System.Drawing.Size(50, 43);
            this.textBox3.TabIndex = 3;
            this.textBox3.Text = "3";
            this.textBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox4
            // 
            this.textBox4.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.textBox4.Location = new System.Drawing.Point(436, 51);
            this.textBox4.Name = "textBox4";
            this.textBox4.ReadOnly = true;
            this.textBox4.Size = new System.Drawing.Size(50, 43);
            this.textBox4.TabIndex = 3;
            this.textBox4.Text = "4";
            this.textBox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox5
            // 
            this.textBox5.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.textBox5.Location = new System.Drawing.Point(533, 51);
            this.textBox5.Name = "textBox5";
            this.textBox5.ReadOnly = true;
            this.textBox5.Size = new System.Drawing.Size(50, 43);
            this.textBox5.TabIndex = 3;
            this.textBox5.Text = "5";
            this.textBox5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox6
            // 
            this.textBox6.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.textBox6.Location = new System.Drawing.Point(633, 51);
            this.textBox6.Name = "textBox6";
            this.textBox6.ReadOnly = true;
            this.textBox6.Size = new System.Drawing.Size(50, 43);
            this.textBox6.TabIndex = 3;
            this.textBox6.Text = "6";
            this.textBox6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox7
            // 
            this.textBox7.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.textBox7.Location = new System.Drawing.Point(737, 51);
            this.textBox7.Name = "textBox7";
            this.textBox7.ReadOnly = true;
            this.textBox7.Size = new System.Drawing.Size(50, 43);
            this.textBox7.TabIndex = 3;
            this.textBox7.Text = "7";
            this.textBox7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox8
            // 
            this.textBox8.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.textBox8.Location = new System.Drawing.Point(837, 51);
            this.textBox8.Name = "textBox8";
            this.textBox8.ReadOnly = true;
            this.textBox8.Size = new System.Drawing.Size(50, 43);
            this.textBox8.TabIndex = 3;
            this.textBox8.Text = "8";
            this.textBox8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // PixelProgramForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(944, 941);
            this.Controls.Add(this.textBox8);
            this.Controls.Add(this.textBox7);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.txtE);
            this.Controls.Add(this.txtF);
            this.Controls.Add(this.txtG);
            this.Controls.Add(this.txtH);
            this.Controls.Add(this.txtD);
            this.Controls.Add(this.txtC);
            this.Controls.Add(this.txtB);
            this.Controls.Add(this.txtA);
            this.Controls.Add(this.C8);
            this.Controls.Add(this.C7);
            this.Controls.Add(this.A8);
            this.Controls.Add(this.B8);
            this.Controls.Add(this.B7);
            this.Controls.Add(this.A7);
            this.Controls.Add(this.A6);
            this.Controls.Add(this.B6);
            this.Controls.Add(this.B5);
            this.Controls.Add(this.A5);
            this.Controls.Add(this.A4);
            this.Controls.Add(this.B4);
            this.Controls.Add(this.C3);
            this.Controls.Add(this.B3);
            this.Controls.Add(this.A3);
            this.Controls.Add(this.C2);
            this.Controls.Add(this.B1);
            this.Controls.Add(this.B2);
            this.Controls.Add(this.E3);
            this.Controls.Add(this.C5);
            this.Controls.Add(this.E1);
            this.Controls.Add(this.D8);
            this.Controls.Add(this.E2);
            this.Controls.Add(this.C4);
            this.Controls.Add(this.C6);
            this.Controls.Add(this.D3);
            this.Controls.Add(this.D6);
            this.Controls.Add(this.D2);
            this.Controls.Add(this.E4);
            this.Controls.Add(this.D4);
            this.Controls.Add(this.E7);
            this.Controls.Add(this.E8);
            this.Controls.Add(this.D5);
            this.Controls.Add(this.E5);
            this.Controls.Add(this.E6);
            this.Controls.Add(this.A2);
            this.Controls.Add(this.H5);
            this.Controls.Add(this.F6);
            this.Controls.Add(this.D1);
            this.Controls.Add(this.F8);
            this.Controls.Add(this.F4);
            this.Controls.Add(this.C1);
            this.Controls.Add(this.D7);
            this.Controls.Add(this.F5);
            this.Controls.Add(this.G8);
            this.Controls.Add(this.G7);
            this.Controls.Add(this.G6);
            this.Controls.Add(this.G5);
            this.Controls.Add(this.H6);
            this.Controls.Add(this.H7);
            this.Controls.Add(this.H8);
            this.Controls.Add(this.A1);
            this.Controls.Add(this.G4);
            this.Controls.Add(this.F7);
            this.Controls.Add(this.F2);
            this.Controls.Add(this.H4);
            this.Controls.Add(this.F3);
            this.Controls.Add(this.H3);
            this.Controls.Add(this.G3);
            this.Controls.Add(this.G2);
            this.Controls.Add(this.H2);
            this.Controls.Add(this.F1);
            this.Controls.Add(this.G1);
            this.Controls.Add(this.H1);
            this.Controls.Add(this.BoardBack);
            this.Name = "PixelProgramForm";
            this.Text = "Chess";
            this.Load += new System.EventHandler(this.PixelProgramForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.BoardBack)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.H1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.G1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.F1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.H2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.G2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.G3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.H3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.F3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.H4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.F2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.F7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.G4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.A1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.H8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.H7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.H6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.G5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.G6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.G7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.G8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.F5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.D7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.F8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.D1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.H5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.F4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.F6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.A2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.E6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.E5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.D5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.E8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.E7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.D4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.E4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.D2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.D6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.D3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.E2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.D8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.B2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.B1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.A3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.B3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.E1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.E3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.B4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.A4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.A5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.B5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.B6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.A6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.A7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.B7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.B8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.A8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C8)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox BoardBack;
        private System.Windows.Forms.PictureBox H1;
        private System.Windows.Forms.PictureBox G1;
        private System.Windows.Forms.PictureBox F1;
        private System.Windows.Forms.PictureBox H2;
        private System.Windows.Forms.PictureBox G2;
        private System.Windows.Forms.PictureBox G3;
        private System.Windows.Forms.PictureBox H3;
        private System.Windows.Forms.PictureBox F3;
        private System.Windows.Forms.PictureBox H4;
        private System.Windows.Forms.PictureBox F2;
        private System.Windows.Forms.PictureBox F7;
        private System.Windows.Forms.PictureBox G4;
        private System.Windows.Forms.PictureBox A1;
        private System.Windows.Forms.PictureBox H8;
        private System.Windows.Forms.PictureBox H7;
        private System.Windows.Forms.PictureBox H6;
        private System.Windows.Forms.PictureBox G5;
        private System.Windows.Forms.PictureBox G6;
        private System.Windows.Forms.PictureBox G7;
        private System.Windows.Forms.PictureBox G8;
        private System.Windows.Forms.PictureBox F5;
        private System.Windows.Forms.PictureBox D7;
        private System.Windows.Forms.PictureBox C1;
        private System.Windows.Forms.PictureBox F8;
        private System.Windows.Forms.PictureBox D1;
        private System.Windows.Forms.PictureBox H5;
        private System.Windows.Forms.PictureBox F4;
        private System.Windows.Forms.PictureBox F6;
        private System.Windows.Forms.PictureBox A2;
        private System.Windows.Forms.PictureBox E6;
        private System.Windows.Forms.PictureBox E5;
        private System.Windows.Forms.PictureBox D5;
        private System.Windows.Forms.PictureBox E8;
        private System.Windows.Forms.PictureBox E7;
        private System.Windows.Forms.PictureBox D4;
        private System.Windows.Forms.PictureBox E4;
        private System.Windows.Forms.PictureBox D2;
        private System.Windows.Forms.PictureBox D6;
        private System.Windows.Forms.PictureBox D3;
        private System.Windows.Forms.PictureBox C6;
        private System.Windows.Forms.PictureBox C4;
        private System.Windows.Forms.PictureBox E2;
        private System.Windows.Forms.PictureBox D8;
        private System.Windows.Forms.PictureBox C5;
        private System.Windows.Forms.PictureBox B2;
        private System.Windows.Forms.PictureBox B1;
        private System.Windows.Forms.PictureBox C2;
        private System.Windows.Forms.PictureBox A3;
        private System.Windows.Forms.PictureBox B3;
        private System.Windows.Forms.PictureBox E1;
        private System.Windows.Forms.PictureBox E3;
        private System.Windows.Forms.PictureBox C3;
        private System.Windows.Forms.PictureBox B4;
        private System.Windows.Forms.PictureBox A4;
        private System.Windows.Forms.PictureBox A5;
        private System.Windows.Forms.PictureBox B5;
        private System.Windows.Forms.PictureBox B6;
        private System.Windows.Forms.PictureBox A6;
        private System.Windows.Forms.PictureBox A7;
        private System.Windows.Forms.PictureBox B7;
        private System.Windows.Forms.PictureBox B8;
        private System.Windows.Forms.PictureBox A8;
        private System.Windows.Forms.PictureBox C7;
        private System.Windows.Forms.PictureBox C8;
        private System.Windows.Forms.TextBox txtA;
        private System.Windows.Forms.TextBox txtB;
        private System.Windows.Forms.TextBox txtC;
        private System.Windows.Forms.TextBox txtD;
        private System.Windows.Forms.TextBox txtH;
        private System.Windows.Forms.TextBox txtG;
        private System.Windows.Forms.TextBox txtF;
        private System.Windows.Forms.TextBox txtE;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox8;
    }
}

