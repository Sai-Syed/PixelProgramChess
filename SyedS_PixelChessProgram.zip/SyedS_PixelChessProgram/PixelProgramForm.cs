﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/*
 * 
 * Saihaan Syed
 * Pixel Program Chess Board
 * This program will be a working chess board
 * 
 * ==============
 * DISCLAIMERS
 * ==============
 * This program uses american spelling like 'color' instead of 'colour' for the sake of staying consistent with syntax. 
 * If there is inconsistancy that is due to the difficulty of of trying to mentally switch to using 'color' instead of 'colour'
 * ====================
 * DISCLAIMERS CLOSED
 * ====================
 */

namespace SyedS_PixelChessProgram
{
    public partial class PixelProgramForm : Form
    {
        List<PositionTracker> positionData = new List<PositionTracker>();
        public PixelProgramForm()
        {
            InitializeComponent();
        }

        private void PixelProgramForm_Load(object sender, EventArgs e)
        {
            //===============================
            //SET STARTING PIECE POSITION
            //===============================
            //==
            //A
            //==
            PositionTracker setPositionA1 = new PositionTracker("a1", true, "white", "rook", A1);
            A1.Image = BitmapFieldStorage.SetRook("white");
            PositionTracker setPositionA2 = new PositionTracker("a2", true, "white", "knight", A2);
            A2.Image = BitmapFieldStorage.SetKnight("white");
            PositionTracker setPositionA3 = new PositionTracker("a3", true, "white", "bishop", A3);
            A3.Image = BitmapFieldStorage.SetBishop("white");
            PositionTracker setPositionA4 = new PositionTracker("a4", true, "white", "queen", A4);
            A4.Image = BitmapFieldStorage.SetQueen("white");
            PositionTracker setPositionA5 = new PositionTracker("a5", true, "white", "king", A5);
            A5.Image = BitmapFieldStorage.SetKing("white");
            PositionTracker setPositionA6 = new PositionTracker("a6", true, "white", "bishop", A6);
            A6.Image = BitmapFieldStorage.SetBishop("white");
            PositionTracker setPositionA7 = new PositionTracker("a7", true, "white", "knight", A7);
            A7.Image = BitmapFieldStorage.SetKnight("white");
            PositionTracker setPositionA8 = new PositionTracker("a8", true, "white", "rook", A8);
            A8.Image = BitmapFieldStorage.SetRook("white");
            //==
            //B
            //==
            PositionTracker setPositionB1 = new PositionTracker("b1", true, "white", "pawn", B1);
            B1.Image = BitmapFieldStorage.SetPawn("white");
            PositionTracker setPositionB2 = new PositionTracker("b2", true, "white", "pawn", B2);
            B2.Image = BitmapFieldStorage.SetPawn("white");
            PositionTracker setPositionB3 = new PositionTracker("b3", true, "white", "pawn", B3);
            B3.Image = BitmapFieldStorage.SetPawn("white");
            PositionTracker setPositionB4 = new PositionTracker("b4", true, "white", "pawn", B4);
            B4.Image = BitmapFieldStorage.SetPawn("white");
            PositionTracker setPositionB5 = new PositionTracker("b5", true, "white", "pawn", B5);
            B5.Image = BitmapFieldStorage.SetPawn("white");
            PositionTracker setPositionB6 = new PositionTracker("b6", true, "white", "pawn", B6);
            B6.Image = BitmapFieldStorage.SetPawn("white");
            PositionTracker setPositionB7 = new PositionTracker("b7", true, "white", "pawn", B7);
            B7.Image = BitmapFieldStorage.SetPawn("white");
            PositionTracker setPositionB8 = new PositionTracker("b8", true, "white", "pawn", B8);
            B8.Image = BitmapFieldStorage.SetPawn("white");
            //==
            //C
            //==
            PositionTracker setPositionC1 = new PositionTracker("c1", false, C1);
            PositionTracker setPositionC2 = new PositionTracker("c2", false, C2);
            PositionTracker setPositionC3 = new PositionTracker("c3", false, C3);
            PositionTracker setPositionC4 = new PositionTracker("c4", false, C4);
            PositionTracker setPositionC5 = new PositionTracker("c5", false, C5);
            PositionTracker setPositionC6 = new PositionTracker("c6", false, C6);
            PositionTracker setPositionC7 = new PositionTracker("c7", false, C7);
            PositionTracker setPositionC8 = new PositionTracker("c8", false, C8);
            //==
            //D
            //==
            PositionTracker setPositionD1 = new PositionTracker("d1", false, D1);
            PositionTracker setPositionD2 = new PositionTracker("d2", false, D2);
            PositionTracker setPositionD3 = new PositionTracker("d3", false, D3);
            PositionTracker setPositionD4 = new PositionTracker("d4", false, D4);
            PositionTracker setPositionD5 = new PositionTracker("d5", false, D5);
            PositionTracker setPositionD6 = new PositionTracker("d6", false, D6);
            PositionTracker setPositionD7 = new PositionTracker("d7", false, D7);
            PositionTracker setPositionD8 = new PositionTracker("d8", false, D8);
            //==
            //E
            //==
            PositionTracker setPositionE1 = new PositionTracker("e1", false, E1);
            PositionTracker setPositionE2 = new PositionTracker("e2", false, E2);
            PositionTracker setPositionE3 = new PositionTracker("e3", false, E3);
            PositionTracker setPositionE4 = new PositionTracker("e4", false, E4);
            PositionTracker setPositionE5 = new PositionTracker("e5", false, E5);
            PositionTracker setPositionE6 = new PositionTracker("e6", false, E6);
            PositionTracker setPositionE7 = new PositionTracker("e7", false, E7);
            PositionTracker setPositionE8 = new PositionTracker("e8", false, E8);
            //==
            //F
            //==
            PositionTracker setPositionF1 = new PositionTracker("f1", false, F1);
            PositionTracker setPositionF2 = new PositionTracker("f2", false, F2);
            PositionTracker setPositionF3 = new PositionTracker("f3", false, F3);
            PositionTracker setPositionF4 = new PositionTracker("f4", false, F4);
            PositionTracker setPositionF5 = new PositionTracker("f5", false, F5);
            PositionTracker setPositionF6 = new PositionTracker("f6", false, F6);
            PositionTracker setPositionF7 = new PositionTracker("f7", false, F7);
            PositionTracker setPositionF8 = new PositionTracker("f8", false, F8);
            //==
            //G
            //==
            PositionTracker setPositionG1 = new PositionTracker("g1", true, "black", "pawn", G1);
            G1.Image = BitmapFieldStorage.SetPawn("black");
            PositionTracker setPositionG2 = new PositionTracker("g2", true, "black", "pawn", G2);
            G2.Image = BitmapFieldStorage.SetPawn("black");
            PositionTracker setPositionG3 = new PositionTracker("g3", true, "black", "pawn", G3);
            G3.Image = BitmapFieldStorage.SetPawn("black");
            PositionTracker setPositionG4 = new PositionTracker("g4", true, "black", "pawn", G4);
            G4.Image = BitmapFieldStorage.SetPawn("black");
            PositionTracker setPositionG5 = new PositionTracker("g5", true, "black", "pawn", G5);
            G5.Image = BitmapFieldStorage.SetPawn("black");
            PositionTracker setPositionG6 = new PositionTracker("g6", true, "black", "pawn", G6);
            G6.Image = BitmapFieldStorage.SetPawn("black");
            PositionTracker setPositionG7 = new PositionTracker("g7", true, "black", "pawn", G7);
            G7.Image = BitmapFieldStorage.SetPawn("black");
            PositionTracker setPositionG8 = new PositionTracker("g8", true, "black", "pawn", G8);
            G8.Image = BitmapFieldStorage.SetPawn("black");
            //==
            //H
            //==
            PositionTracker setPositionH1 = new PositionTracker("h1", true, "black", "rook", H1);
            H1.Image = BitmapFieldStorage.SetRook("black");
            PositionTracker setPositionH2 = new PositionTracker("h2", true, "black", "knight", H2);
            H2.Image = BitmapFieldStorage.SetKnight("black");
            PositionTracker setPositionH3 = new PositionTracker("h3", true, "black", "bishop", H3);
            H3.Image = BitmapFieldStorage.SetBishop("black");
            PositionTracker setPositionH4 = new PositionTracker("h4", true, "black", "queen", H4);
            H4.Image = BitmapFieldStorage.SetQueen("black");
            PositionTracker setPositionH5 = new PositionTracker("h5", true, "black", "king", H5);
            H5.Image = BitmapFieldStorage.SetKing("black");
            PositionTracker setPositionH6 = new PositionTracker("h6", true, "black", "bishop", H6);
            H6.Image = BitmapFieldStorage.SetBishop("black");
            PositionTracker setPositionH7 = new PositionTracker("h7", true, "black", "knight", H7);
            H7.Image = BitmapFieldStorage.SetKnight("black");
            PositionTracker setPositionH8 = new PositionTracker("h8", true, "black", "rook", H8);
            H8.Image = BitmapFieldStorage.SetRook("black");

            positionData.AddRange(new List<PositionTracker>() { setPositionA1, setPositionA2, setPositionA3, setPositionA4, setPositionA5, setPositionA6, setPositionA7, setPositionA8 });
            positionData.AddRange(new List<PositionTracker>() { setPositionB1, setPositionB2, setPositionB3, setPositionB4, setPositionB5, setPositionB6, setPositionB7, setPositionB8 });
            positionData.AddRange(new List<PositionTracker>() { setPositionC1, setPositionC2, setPositionC3, setPositionC4, setPositionC5, setPositionC6, setPositionC7, setPositionC8 });
            positionData.AddRange(new List<PositionTracker>() { setPositionD1, setPositionD2, setPositionD3, setPositionD4, setPositionD5, setPositionD6, setPositionD7, setPositionD8 });
            positionData.AddRange(new List<PositionTracker>() { setPositionE1, setPositionE2, setPositionE3, setPositionE4, setPositionE5, setPositionE6, setPositionE7, setPositionE8 });
            positionData.AddRange(new List<PositionTracker>() { setPositionF1, setPositionF2, setPositionF3, setPositionF4, setPositionF5, setPositionF6, setPositionF7, setPositionF8 });
            positionData.AddRange(new List<PositionTracker>() { setPositionG1, setPositionG2, setPositionG3, setPositionG4, setPositionG5, setPositionG6, setPositionG7, setPositionG8, });
            positionData.AddRange(new List<PositionTracker>() { setPositionH1, setPositionH2, setPositionH3, setPositionH4, setPositionH5, setPositionH6, setPositionH7, setPositionH8 });
        }

        private void A1_Click(object sender, EventArgs e)
        {
            A1.Image = ClickManagement.ClickInTake(this, 0, ref positionData);
        }

        private void A2_Click(object sender, EventArgs e)
        {
            A2.Image = ClickManagement.ClickInTake(this, 1, ref positionData);
        }
        private void A3_Click(object sender, EventArgs e)
        {
            A3.Image = ClickManagement.ClickInTake(this, 2, ref positionData);
        }
        private void A4_Click(object sender, EventArgs e)
        {
            A4.Image = ClickManagement.ClickInTake(this, 3, ref positionData);
        }
        private void A5_Click(object sender, EventArgs e)
        {
            A5.Image = ClickManagement.ClickInTake(this, 4, ref positionData);
        }

        private void A6_Click(object sender, EventArgs e)
        {
            A6.Image = ClickManagement.ClickInTake(this, 5, ref positionData);
        }
        private void A7_Click(object sender, EventArgs e)
        {
            A7.Image = ClickManagement.ClickInTake(this, 6, ref positionData);
        }

        private void A8_Click(object sender, EventArgs e)
        {
            A8.Image = ClickManagement.ClickInTake(this, 7, ref positionData);
        }

        private void B1_Click(object sender, EventArgs e)
        {
            B1.Image = ClickManagement.ClickInTake(this, 8, ref positionData);
        }
        private void B2_Click(object sender, EventArgs e)
        {
            B2.Image = ClickManagement.ClickInTake(this, 9, ref positionData);
        }

        private void B3_Click(object sender, EventArgs e)
        {
            B3.Image = ClickManagement.ClickInTake(this, 10, ref positionData);
        }

        private void B4_Click(object sender, EventArgs e)
        {
            B4.Image = ClickManagement.ClickInTake(this, 11, ref positionData);
        }

        private void B5_Click(object sender, EventArgs e)
        {
            B5.Image = ClickManagement.ClickInTake(this, 12, ref positionData);
        }

        private void B6_Click(object sender, EventArgs e)
        {
            B6.Image = ClickManagement.ClickInTake(this, 13, ref positionData);
        }

        private void B7_Click(object sender, EventArgs e)
        {
            B7.Image = ClickManagement.ClickInTake(this, 14, ref positionData);
        }

        private void B8_Click(object sender, EventArgs e)
        {
            B8.Image = ClickManagement.ClickInTake(this, 15, ref positionData);
        }

        private void C1_Click(object sender, EventArgs e)
        {
            C1.Image = ClickManagement.ClickInTake(this, 16, ref positionData);
        }

        private void C2_Click(object sender, EventArgs e)
        {
            C2.Image = ClickManagement.ClickInTake(this, 17, ref positionData);
        }

        private void C3_Click(object sender, EventArgs e)
        {
            C3.Image = ClickManagement.ClickInTake(this, 18, ref positionData);
        }

        private void C4_Click(object sender, EventArgs e)
        {
            C4.Image = ClickManagement.ClickInTake(this, 19, ref positionData);
        }

        private void C5_Click(object sender, EventArgs e)
        {
            C5.Image = ClickManagement.ClickInTake(this, 20, ref positionData);
        }

        private void C6_Click(object sender, EventArgs e)
        {
            C6.Image = ClickManagement.ClickInTake(this, 21, ref positionData);
        }

        private void C7_Click(object sender, EventArgs e)
        {
            C7.Image = ClickManagement.ClickInTake(this, 22, ref positionData);
        }

        private void C8_Click(object sender, EventArgs e)
        {
            C8.Image = ClickManagement.ClickInTake(this, 23, ref positionData);
        }

        private void D1_Click(object sender, EventArgs e)
        {
            D1.Image = ClickManagement.ClickInTake(this, 24, ref positionData);
        }

        private void D2_Click(object sender, EventArgs e)
        {
            D2.Image = ClickManagement.ClickInTake(this, 25, ref positionData);
        }

        private void D3_Click(object sender, EventArgs e)
        {
            D3.Image = ClickManagement.ClickInTake(this, 26, ref positionData);
        }

        private void D4_Click(object sender, EventArgs e)
        {
            D4.Image = ClickManagement.ClickInTake(this, 27, ref positionData);
        }

        private void D5_Click(object sender, EventArgs e)
        {
            D5.Image = ClickManagement.ClickInTake(this, 28, ref positionData);
        }

        private void D6_Click(object sender, EventArgs e)
        {
            D6.Image = ClickManagement.ClickInTake(this, 29, ref positionData);
        }

        private void D7_Click(object sender, EventArgs e)
        {
            D7.Image = ClickManagement.ClickInTake(this, 30, ref positionData);
        }

        private void D8_Click(object sender, EventArgs e)
        {
            D8.Image = ClickManagement.ClickInTake(this, 31, ref positionData);
        }
        private void E1_Click(object sender, EventArgs e)
        {
            E1.Image = ClickManagement.ClickInTake(this, 32, ref positionData);
        }

        private void E2_Click(object sender, EventArgs e)
        {
            E2.Image = ClickManagement.ClickInTake(this, 33, ref positionData);
        }

        private void E3_Click(object sender, EventArgs e)
        {
            E3.Image = ClickManagement.ClickInTake(this, 34, ref positionData);
        }

        private void E4_Click(object sender, EventArgs e)
        {
            E4.Image = ClickManagement.ClickInTake(this, 35, ref positionData);
        }

        private void E5_Click(object sender, EventArgs e)
        {
            E5.Image = ClickManagement.ClickInTake(this, 36, ref positionData);
        }

        private void E6_Click(object sender, EventArgs e)
        {
            E6.Image = ClickManagement.ClickInTake(this, 37, ref positionData);
        }

        private void E7_Click(object sender, EventArgs e)
        {
            E7.Image = ClickManagement.ClickInTake(this, 38, ref positionData);
        }
        private void E8_Click(object sender, EventArgs e)
        {
            E8.Image = ClickManagement.ClickInTake(this, 39, ref positionData);
        }

        private void F1_Click(object sender, EventArgs e)
        {
            F1.Image = ClickManagement.ClickInTake(this, 40, ref positionData);
        }

        private void F2_Click(object sender, EventArgs e)
        {
            F2.Image = ClickManagement.ClickInTake(this, 41, ref positionData);
        }

        private void F3_Click(object sender, EventArgs e)
        {
            F3.Image = ClickManagement.ClickInTake(this, 42, ref positionData);
        }

        private void F4_Click(object sender, EventArgs e)
        {
            F4.Image = ClickManagement.ClickInTake(this, 43, ref positionData);
        }

        private void F5_Click(object sender, EventArgs e)
        {
            F5.Image = ClickManagement.ClickInTake(this, 44, ref positionData);
        }

        private void F6_Click(object sender, EventArgs e)
        {
            F6.Image = ClickManagement.ClickInTake(this, 45, ref positionData);
        }

        private void F7_Click(object sender, EventArgs e)
        {
            F7.Image = ClickManagement.ClickInTake(this, 46, ref positionData);
        }

        private void F8_Click(object sender, EventArgs e)
        {
            F8.Image = ClickManagement.ClickInTake(this, 47, ref positionData);
        }

        private void G1_Click(object sender, EventArgs e)
        {
            G1.Image = ClickManagement.ClickInTake(this, 48, ref positionData);
        }

        private void G2_Click(object sender, EventArgs e)
        {
            G2.Image = ClickManagement.ClickInTake(this, 49, ref positionData);
        }

        private void G3_Click(object sender, EventArgs e)
        {
            G3.Image = ClickManagement.ClickInTake(this, 50, ref positionData);
        }

        private void G4_Click(object sender, EventArgs e)
        {
            G4.Image = ClickManagement.ClickInTake(this, 51, ref positionData);
        }

        private void G5_Click(object sender, EventArgs e)
        {
            G5.Image = ClickManagement.ClickInTake(this, 52, ref positionData);
        }

        private void G6_Click(object sender, EventArgs e)
        {
            G6.Image = ClickManagement.ClickInTake(this, 53, ref positionData);
        }

        private void G7_Click(object sender, EventArgs e)
        {
            G7.Image = ClickManagement.ClickInTake(this, 54, ref positionData);
        }

        private void G8_Click(object sender, EventArgs e)
        {
            G8.Image = ClickManagement.ClickInTake(this, 55, ref positionData);
        }

        private void H1_Click(object sender, EventArgs e)
        {
            H1.Image = ClickManagement.ClickInTake(this, 56, ref positionData);
        }

        private void H2_Click(object sender, EventArgs e)
        {
            H2.Image = ClickManagement.ClickInTake(this, 57, ref positionData);
        }

        private void H3_Click(object sender, EventArgs e)
        {
            H3.Image = ClickManagement.ClickInTake(this, 58, ref positionData);
        }

        private void H4_Click(object sender, EventArgs e)
        {
            H4.Image = ClickManagement.ClickInTake(this, 59, ref positionData);
        }

        private void H5_Click(object sender, EventArgs e)
        {
            H5.Image = ClickManagement.ClickInTake(this, 60, ref positionData);
        }

        private void H6_Click(object sender, EventArgs e)
        {
            H6.Image = ClickManagement.ClickInTake(this, 61, ref positionData);
        }

        private void H7_Click(object sender, EventArgs e)
        {
            H7.Image = ClickManagement.ClickInTake(this, 62, ref positionData);
        }

        private void H8_Click(object sender, EventArgs e)
        {
            H8.Image = ClickManagement.ClickInTake(this, 63, ref positionData);
        }
    }
}
